package com.tours;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class TeluskoToursProjectApplicationTests {

	@Test
	void contextLoads() {
	}

}
